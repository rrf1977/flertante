import 'package:flutter/material.dart';
// import 'dart:math'; // used for random so far
import 'package:flutter/rendering.dart'; // for random numbers
// import 'package:flutter_svg/flutter_svg.dart';// Note - 2020y06m17d 10:36:58 - RRF - not working!!!

//// classes from parallel scopes ///////////{
// import "names_generator.dart";
// import "occupation_generator.dart";
import "person.dart";
import './screens/entrance.dart';
import './screens/login.dart';
import './screens/listing_users.dart';
import 'style_and_decorations.dart';
/////////////////////////////////////////////}

// Note - 2020y07m10d 08:11:01 - RRF - moved to names_generator.dart
  // String getNames(int code){ }

// Note - 2020y07m10d 08:12:58 - RRF - moved to occupation_generator.dart
  // String getOccupations(int code){ }

// Note - 2020y07m10d 08:17:10 - RRF - moved do person.dart
  // Person()

void mainAux() { // testing functionalities in the console
  List<Person>people = [];
  int radiusDistance = 50;

  int concise = 0;

  for (int i = 0; i < radiusDistance; i++) {
//    print('hello ${i + 1}');
      Person p = new Person();
      people.add(p);
      // console version:
      //// testing how they will be listed:
      if (concise == 0){
        print("[foto] ${p.getFullName}, ${p.getAge} anos."); // for testing in the console.
        // print("\tinformações adicionais: altura: ${p.height/100} m; peso: ${p.weight} kilos."); // for testing in the console.
      }
      //// testing how they will look like when opened:
      else if (concise == 1) {
        print("\t--------\n\t| foto |\n\t--------\nNome: ${p.getFullName}\nIdade ${p.getAge} anos\nAltura: ${p.height/100} m\nPeso: ${p.weight} kilos\nProfissão: ${p.occupation}"); // for testing in the console.
      }
      print("_"*40);
  }
}

//// my custom colors////////////////////////{ // Note - 2020y06m17d 09:03:37 - RRF - I still don't know how to make this variable globals
// Note - 2020y07m10d 09:41:39 - RRF - moved to styles_and_decorations.dart
/////////////////////////////////////////////}

//// CustomDecorations //////////////////////{
BoxDecoration decorationTester() {
  return BoxDecoration(
    border: Border.all(
      width: 2.0,
      color: Colors.red,
    ),
//    borderRadius: BorderRadius.all(Radius.circular(8.0)),
  );
}

FlutterLogoDecoration logoDecoration (){// Note - 2020y06m17d 11:00:14 - RRF - pending
return FlutterLogoDecoration();
}

BoxDecoration logoAreaDecoration() {
  return BoxDecoration(
//    color: Colors.teal[50],
    color: displayGray,

    // border: Border.all(
//      color: Color(0xFF000000),
      // color: Color(0xFF444433),
      // width: 3.0
    // ),
    // borderRadius: BorderRadius.all(
    //   Radius.circular(8.0) //         <--- border radius here
    // ),

    //unfortunately, the "BorderSide" doesn't work along with "BorderRadius"
    /*    border: Border(
      left: BorderSide(
        color: Color(0x22000000),
        width: 8.0,
      ),
      top: BorderSide(
        color: Color(0x22000000),
        width: 8.0,
      ),
      right: BorderSide(
        color: Color(0x22FFFFFF),
        width: 8.0,
      ),
      bottom: BorderSide(
        color: Color(0x22FFFFFF),
        width: 8.0,
      ),
    ),
*/

  );
}
BoxDecoration cardLoginScreen() {
  
  return BoxDecoration(
    color: Colors.white,
    // border: Border.all(
    //   color: Color(0xFF000000), // for testing only
    //   width: 1.0, // for testing only
    // ),
    borderRadius: BorderRadius.all(
      Radius.circular(16.0)
    ),
  );
}
BoxDecoration cardThinFrame() {
  return BoxDecoration(
    border: Border.all(
      width: 1.0,
      color: cardInnerCanvasThinBorder,
    ),
//    borderRadius: BorderRadius.all(Radius.circular(8.0)),
  );
}

/////////////////////////////////////////////}


//// flertante //////////////////////////////{  
// class ChoosePeople extends StatefulWidget {
//   final int radiusDistance = 50;

//   ChoosePeople(){
//     List<Person>people = [];
//     for (int i = 0; i < radiusDistance; i++) {
//         Person p = new Person();
//         people.add(p);
//     }
//   }
//   @override
//   Widget build(BuildContext context){
//     return _ChoosePeopleState(context);
//   }
// }

//   @override
//   _ChoosePeopleState createState() => _ChoosePeopleState();

// // class _ChoosePeopleState extends State<ChoosePeople> {
// class _ChoosePeopleState extends State<ChoosePeople> {

//   // List<Person>people = [new Person(),new Person(),new Person(),new Person(),new Person()];
//   // int radiusDistance = 50;

//   // ChoosePeople(){ 
//   //   for (int i = 0; i < radiusDistance; i++) {
//   //       Person p = new Person();
//   //       this.people.add(p);
//   //   }
//   // }

//   @override
//   Widget build(){
//     return Scaffold(
//       backgroundColor: concreteGray,
//       appBar: AppBar(
//         backgroundColor: Colors.deepPurple,
//         title: Text("Pessoas interessantes nas proximidades."),
//         centerTitle: true,
//         elevation: 0, // 2020-06-16_17-51-36 what is elevation?
//         ),
//         body: ListView.builder(
//           itemCount: people.length,
//           itemBuilder: (context,index){
//             return Padding(
//               // padding: const EdgeInsets.all(8.0),
//               padding: const EdgeInsets.symmetric(vertical: 1.0,horizontal: 4.0),
//               child: Card(
//                 child: ListTile(
//                   onTap: (){},
//                   // print("${people[index.getFullName]}"),// console testing
//                   title: Text("\${people[index.getFullName]}"),
//                   leading: CircleAvatar(
//                     // backgroundImage: Icon(Icons.people),
//                     // backgroundImage: AssetImage(),// for the future.
//                   ),
//                 )
//               ),
//             );
//           }
//         )
//     );
//   }

// }
/////////////////////////////////////////////}

//// acquired from tutorials. (studying) ////{
//// FlutterDemoHomePage ////////////////////{

// Copyright (c) 2019, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

class MyAppFutterDemoHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ),
    );
  }
}
/////////////////////////////////////////////}
/////////////////////////////////////////////}

//// ListingUsers ///////////////////////////{
// Note - 2020y07m10d 09:17:25 - RRF - moved to ./screens/listing_users.dart
/////////////////////////////////////////////}

//// SearchNearBy////////////////////////////{
class SearchNearBy extends StatefulWidget {
  @override
  _SearchNearByState createState() => _SearchNearByState();
}

class _SearchNearByState extends State<SearchNearBy> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}
/////////////////////////////////////////////}

//// PersonProfile///////////////////////////{
class PersonProfile extends StatefulWidget {
  @override
  _PersonProfileState createState() => _PersonProfileState();
}

class _PersonProfileState extends State<PersonProfile> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}
/////////////////////////////////////////////}

//// EntranceScreen//////////////////////////{
// Note - 2020y07m10d 09:15:00 - RRF - moved to ./screens/entrance.dart
/////////////////////////////////////////////}

//// LoginScreen ////////////////////////////{
// Note - 2020y07m10d 09:14:21 - RRF - moved to ./screens/login.dart
/////////////////////////////////////////////}

//// main ///////////////////////////////////{
// void main() => runApp(ListingUsers());
void main() {
  runApp(
    MaterialApp(
        debugShowCheckedModeBanner: false, 
        title: 'Navegação', 
//        home: MyApp(),// when we put "initialRoute", this one here is no longer necessary (from Professor Plotze's class of 8/may/2020).

        //Navigation routes
        initialRoute: '/pageEntrance',
        routes:{
          '/pageEntrance': (context) => Entrance(),
          '/pageLogin': (context) => LoginScreen(),
          '/pageSearchNearBy': (context) => SearchNearBy(),
          // '/pageChoosePeople': (context) => ChoosePeople(),
          '/pagePersonProfile': (context) => PersonProfile(),
          '/pageListingUsers': (context) => ListingUsers(),
          '/pageFlutterDemo': (context) => MyAppFutterDemoHomePage(),
        }
    ),
  );
}
/////////////////////////////////////////////}

//// sketches ///////////////////////////////{
// Note - 2020y07m10d 09:10:03 - RRF - moved to "./sketches/sketches.dart"
/////////////////////////////////////////////}